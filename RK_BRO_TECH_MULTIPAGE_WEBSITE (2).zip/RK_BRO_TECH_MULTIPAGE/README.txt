RK BRO TECH MULTI-PAGE WEBSITE
Pages: index.html (Home), about.html (About), videos.html, cars.html, tech.html, music.html, contact.html.
Your logo is in assets/rk-bro-tech-logo.jpg.

HOW TO ADD/CHANGE THE LOGO:
1. Keep the image inside the assets folder.
2. Current logo path is assets/rk-bro-tech-logo.jpg and is already used in the header on every page and the Home/About pages.
3. To replace it, put your new logo in the assets folder and name it rk-bro-tech-logo.jpg (replace the existing file). All pages update automatically.
4. Keep the assets folder beside the HTML files.
5. Extract the ZIP, then open index.html in your browser.
To publish, upload all files and the assets folder to GitHub Pages or Netlify.
